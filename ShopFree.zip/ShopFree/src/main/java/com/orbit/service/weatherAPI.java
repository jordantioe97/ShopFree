package com.orbit.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.*;
import com.google.gson.reflect.*;

public class weatherAPI {
	
	public static Map<String, Object> jsonToMap(String str) {
		Map<String, Object> map = new Gson().fromJson(
				str, new TypeToken<HashMap<String, Object>>() {}.getType()
			);
		return map;
	}
	
	public ArrayList<weather> getWeather(String urlStr, String apikey, String zip) {	
		ArrayList<weather> weatherList = new ArrayList<weather>();
		String API_KEY = apikey;
		String ZIPCODE = zip;
		String urlString = urlStr + ZIPCODE + "&appid=" + API_KEY +
		"&units=imperial";
		
		
		try {
			StringBuilder result = new StringBuilder();
			URL url = new URL(urlString);
			URLConnection conn = url.openConnection();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = rd.readLine()) != null) {
				result .append(line);
			}
			rd.close();
			//System.out.println(result.toString());
			Map<String, Object> respMap = jsonToMap(result.toString());
			Map<String, Object> mainMap = jsonToMap(respMap.get("main").toString());
			Map<String, Object> windMap = jsonToMap(respMap.get("wind").toString());
						
			weather wdata = new weather();
			//System.out.println(respMap.get("name"));
			wdata.setCity(respMap.get("name").toString());
			wdata.setTemp(mainMap.get("temp").toString());
			wdata.setHumidity(mainMap.get("humidity").toString());
			wdata.setSpeed(windMap.get("speed").toString());
			wdata.setDeg(windMap.get("deg").toString());
			
			weatherList.add(wdata);
		} catch (IOException e) {
				System.out.println(e.getMessage());
		}
		return weatherList;
	}
}
