package com.orbit.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class appConfig {
	private String weather_url;
	private String weather_apikey;
	private String weather_zip;
	private String db_user;
	private String db_password;
	private String db_url;
	private String key;
	private String cookies_enabled;
	private String clearCookiesOnLogout;
	private String email_notification_enabled;
	private String email_sender;
	private String email_sender_password;
	
	public appConfig() {

        try (InputStream input = appConfig.class.getClassLoader().getResourceAsStream("config.properties")) {

            Properties prop = new Properties();

            if (input == null) {
                System.out.println("Sorry, unable to find config.properties");
                return;
            }

            //load a properties file from class path, inside static method
            prop.load(input);
            
            db_user = prop.getProperty("db.user");
            db_password = prop.getProperty("db.password");
            db_url = prop.getProperty("db.url");
            weather_url = prop.getProperty("weather.url");
            weather_apikey = prop.getProperty("weather.apikey");
            weather_zip = prop.getProperty("weather.zip");
            key = prop.getProperty("security.key");
            cookies_enabled = prop.getProperty("cookies.enabled");
            clearCookiesOnLogout = prop.getProperty("clearCookiesOnLogout");
            email_notification_enabled = prop.getProperty("email_notification_enabled");
            email_sender = prop.getProperty("email_sender");
            email_sender_password = prop.getProperty("email_sender_password");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
	
    public String getWeather_url() {
		return weather_url;
	}

	public String getWeather_apikey() {
		return weather_apikey;
	}

	public String getWeather_zip() {
		return weather_zip;
	}
	public String getDb_user() {
		return db_user;
	}

	public String getDb_password() {
		return db_password;
	}

	public String getDb_url() {
		return db_url;
	}

	public String getKey() {
		return key;
	}

	public String getCookies_enabled() {
		return cookies_enabled;
	}

	public String getClearCookiesOnLogout() {
		return clearCookiesOnLogout;
	}

	public String getEmail_notification_enabled() {
		return email_notification_enabled;
	}

	public String getEmail_sender() {
		return email_sender;
	}

	public String getEmail_sender_password() {
		return email_sender_password;
	}
	
}
