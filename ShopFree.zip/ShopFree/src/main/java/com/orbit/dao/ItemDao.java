package com.orbit.dao;

import java.sql.*;
import java.util.ArrayList;

public class ItemDao 
{
	private String db_url;
	private String db_username;
	private String db_password;
	public ItemDao(String url, String username, String password) {
		db_url = url;
		db_username = username;
		db_password = password;
	}
	public ArrayList<Item> getItem(int item_id)
	{
		ArrayList<Item> itemList = new ArrayList<Item>();
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(db_url,db_username,db_password);
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from item where id = " + item_id);
			while (rs.next()) {
				Item i = new Item();
				i.setItem_id(rs.getInt("id"));
				i.setCategory_id(rs.getInt("category_id"));
				i.setItem_name(rs.getString("item_name"));
				i.setItem_price(rs.getDouble("item_price"));
				i.setPicture(rs.getString("picture"));
				i.setDescription(rs.getString("description"));
				itemList.add(i);
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		System.out.println(itemList.toString());
		return itemList;
	}
}