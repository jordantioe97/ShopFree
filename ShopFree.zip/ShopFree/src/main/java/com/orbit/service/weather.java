package com.orbit.service;

public class weather {
	private String city;
	private String temp;
	private String humidity;
	private String speed;
	private String deg;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTemp() {
		return temp;
	}
	public void setTemp(String temp) {
		this.temp = temp;
	}
	public String getHumidity() {
		return humidity;
	}
	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	public String getDeg() {
		return deg;
	}
	public void setDeg(String deg) {
		this.deg = deg;
	}
	@Override
	public String toString() {
		return "weather [temp=" + temp + ", humidity=" + humidity + ", speed=" + speed + ", deg=" + deg + "]";
	}
	
	
}
