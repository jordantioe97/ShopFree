package com.orbit.dao;

import java.nio.charset.StandardCharsets;
import java.sql.*;
import com.orbit.service.EncryptorAesGcmPassword;
import com.orbit.service.appConfig;
public class LoginDao {
	private String db_url;
	private String db_username;
	private String db_password;
	public LoginDao(String url, String username, String password) {
		db_url = url;
		db_username = username;
		db_password = password;
	}
	public boolean matchUser(String username, String password) {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection(db_url, db_username, db_password);
		Statement st= con.createStatement();
		String sqlString = "select username, password from user where username='"+username+"' and password='"+password+"'";
		ResultSet rs=st.executeQuery(sqlString);
		//System.out.println("SQL String: " + sqlString);
		//System.out.println("Password: " + password);
		
		if (rs.next()) {
			if(rs.getString("username").equals(username) && rs.getString("password").equals(password))
			{
				return true;
			}
		}
		else {
			return false;
		}
		}
		catch (Exception e) {
		e.printStackTrace();
		}
	return false;
	}
}
