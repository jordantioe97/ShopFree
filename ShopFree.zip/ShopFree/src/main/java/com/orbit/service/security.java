package com.orbit.service;
import com.orbit.service.appConfig;
public class security {
	appConfig config = new appConfig();
	public String encrypt(String password) {
		String newStr = "";
		int key = Integer.parseInt(config.getKey());
		System.out.println("Regular text: " + password);
		char[] chars = password.toCharArray();
		System.out.print("Encrypted text: ");
		for (char c : chars) {
			c += key;
			System.out.println(c);
			newStr = newStr + c;
			System.out.println("newStr: " + newStr);
		}
		return newStr;
	}
	public String decrypt(String password) {
		String newStr = "";
		int key = Integer.parseInt(config.getKey());
		System.out.println("Regular text: " + password);
		char[] chars = password.toCharArray();
		System.out.print("Decrypted text: ");
		for (char c : chars) {
			c -= key;
			System.out.println(c);
			newStr = newStr + c;
			System.out.println("newStr: " + newStr);
		}
		return newStr;
	}
}
