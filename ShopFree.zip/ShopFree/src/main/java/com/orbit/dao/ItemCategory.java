package com.orbit.dao;

public class ItemCategory {
	private String category_name;
	private String item_name;
	private String picture;
	private String description;
	private String link;
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	@Override
	public String toString() {
		return "ItemCategory [category_name=" + category_name + ", item_name=" + item_name + ", picture=" + picture
				+ ", description=" + description + "]";
	}
}