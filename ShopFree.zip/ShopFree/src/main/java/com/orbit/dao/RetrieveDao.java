package com.orbit.dao;

import java.sql.*;
public class RetrieveDao {
	private String db_url;
	private String db_username;
	private String db_password;
	public RetrieveDao(String url, String username, String password) {
		db_url = url;
		db_username = username;
		db_password = password;
	}
	public String findPassword(String username, String email) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(db_url,db_username,db_password);
			Statement st = con.createStatement();
			String sqlString = "select username, email, password from user where username = " + "\"" + username + "\"" + " and email = " + "\"" + email + "\"";
			ResultSet rs = st.executeQuery(sqlString);
			if (rs.next()) {
				return rs.getString("password");
			}
			else {
				return "ERROR";
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return "ERROR";
	}
}
