package com.orbit.dao;

public class Item {
	private int item_id;
	private int category_id;
	private String item_name;
	private double item_price;
	private String picture;
	private String description;
	public int getId() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public double getItem_price() {
		return item_price;
	}
	public void setItem_price(double item_price) {
		this.item_price = item_price;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Item [item_id=" + item_id + ", category_id=" + category_id + ", item_name=" + item_name + ", item_price="
				+ item_price + ", picture=" + picture + ", description=" + description + "]";
	}
}
