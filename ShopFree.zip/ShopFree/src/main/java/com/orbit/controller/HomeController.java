package com.orbit.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.orbit.dao.Item;
import com.orbit.dao.ItemDao;
import com.orbit.dao.LoginDao;
import com.orbit.dao.RegisterDao;
import com.orbit.dao.RetrieveDao;
import com.orbit.dao.Category;
import com.orbit.service.appConfig;
import com.orbit.dao.ItemCategory;
import com.orbit.dao.ItemCategoryDao;
//import com.orbit.service.EncryptorAesGcmPassword;
import com.orbit.service.SimplifiedAes;
import com.orbit.service.appConfig;
import com.orbit.service.categoryNav;
import com.orbit.service.weather;
import com.orbit.service.weatherAPI;
import com.orbit.service.JavaMailUtil;
import com.orbit.service.SendEmail;

@Controller
public class HomeController extends HttpServlet {
	private String weather_URL;
	private String weather_APIKEY;
	private String weather_zip;
	private String secret_key;
	private String db_url;
	private String db_username;
	private String db_password;
	private String cookies_enabled;
	private String clearCookiesOnLogout;
	private String email_notification_enabled;

	@ModelAttribute 
	public void loadConfigProperties(HttpServletRequest request, HttpServletResponse response) {
		//System.out.println("Controller: loadConfigProperties..."); 
		appConfig conf = new appConfig();
	  
		weather_URL = conf.getWeather_url();
		weather_APIKEY = conf.getWeather_apikey();
		weather_zip = conf.getWeather_zip();
		secret_key = conf.getKey();
		db_url = conf.getDb_url();
		db_username = conf.getDb_user();
		db_password = conf.getDb_password();
		cookies_enabled = conf.getCookies_enabled();
		clearCookiesOnLogout = conf.getClearCookiesOnLogout();
		email_notification_enabled = conf.getEmail_notification_enabled();
	}
	
	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public ModelAndView getData(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ModelAndView model = new ModelAndView("home");
		categoryNav catNav = new categoryNav();
		// File("C:\\Users\\jorda\\eclipse-workspace\\ShopFree\\src\\main\\webapp\\WEB-INF\\pages\\category.xml");
		ArrayList<Category> categoryList = new ArrayList<Category>();
		categoryList = catNav.getCategory();
		HttpSession session = request.getSession();
		session.setAttribute("categoryList", categoryList);
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i=0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				//System.out.println("Cookies name: " + cookie.getName());
				if (cookie.getName().equals("username_cookie") && !cookie.getName().equals(null)) {
					//System.out.println("Cookies: " + cookie.getValue());
					session.setAttribute("username", cookie.getValue());
				}
			}
		}
		return model;
	}

	@RequestMapping(value = { "/getItemCategory" }, method = RequestMethod.GET)
	protected void doGetItemcategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<ItemCategory> itemCategoryList = new ArrayList<ItemCategory>();
		int category_id = Integer.parseInt(request.getParameter("cid"));
		ItemCategoryDao dao = new ItemCategoryDao(db_url, db_username, db_password);
		itemCategoryList = dao.getItemCategory(category_id);
		HttpSession session = request.getSession();
		session.setAttribute("itemCategoryList", itemCategoryList);
		response.sendRedirect("showItemCategory");

	}

	@RequestMapping(value = { "/showItemCategory" }, method = RequestMethod.GET)
	protected ModelAndView doShowItemCategory() {
		ModelAndView model = new ModelAndView("showItemCategory");
		return model;
	}

	@RequestMapping(value = { "/getItem" }, method = RequestMethod.GET)
	protected void doGetitem(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Item> itemList = new ArrayList<Item>();
		int item_id = Integer.parseInt(request.getParameter("item_id"));
		ItemDao dao = new ItemDao(db_url, db_username, db_password);
		itemList = dao.getItem(item_id);
		HttpSession session = request.getSession();
		session.setAttribute("itemList", itemList);
		response.sendRedirect("showItem");
	}

	@RequestMapping(value = { "/showItem" }, method = RequestMethod.GET)
	protected ModelAndView doShowItem() {
		ModelAndView model = new ModelAndView("showItem");
		return model;
	}

	@RequestMapping(value = { "/goToRacing" }, method = RequestMethod.GET)
	protected ModelAndView doShowGame1() {
		ModelAndView model = new ModelAndView("racing");
		return model;
	}

	@RequestMapping(value = { "/goToCar1" }, method = RequestMethod.GET)
	protected ModelAndView doShowCar1() {
		ModelAndView model = new ModelAndView("carone");
		return model;
	}

	@RequestMapping(value = { "/goToCar2" }, method = RequestMethod.GET)
	protected ModelAndView doShowCar2() {
		ModelAndView model = new ModelAndView("cartwo");
		return model;
	}

	@RequestMapping(value = { "/goToCar3" }, method = RequestMethod.GET)
	protected ModelAndView doShowCar3() {
		ModelAndView model = new ModelAndView("carthree");
		return model;
	}

	@RequestMapping(value = { "/goToGravity" }, method = RequestMethod.GET)
	protected ModelAndView doShowGame2() {
		ModelAndView model = new ModelAndView("gravity");
		return model;
	}

	@RequestMapping(value = { "/goToWinwheel" }, method = RequestMethod.GET)
	protected ModelAndView doShowGame3() {
		ModelAndView model = new ModelAndView("mainwheel");
		return model;
	}

	@RequestMapping(value = { "/goToWeather" }, method = RequestMethod.GET)
	protected void doGetWeather(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<weather> weatherList = new ArrayList<weather>();
		weatherAPI wa = new weatherAPI();
		weatherList = wa.getWeather(weather_URL, weather_APIKEY, weather_zip);
		HttpSession session = request.getSession();
		session.setAttribute("weatherList", weatherList);
		response.sendRedirect("showWeather");
	}

	@RequestMapping(value = { "/showWeather" }, method = RequestMethod.GET)
	protected ModelAndView doShowWeather() {
		ModelAndView model = new ModelAndView("showWeather");
		return model;
	}

	@RequestMapping(value = "/goToRegister", method = RequestMethod.GET)
	public ModelAndView goToRegister() {
		ModelAndView model = new ModelAndView("register");
		return model;
	}

	@RequestMapping(value = { "/getRegister" }, method = RequestMethod.GET)
	public void getRegister(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// security cipher = new security();
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String pText = request.getParameter("password");
		// EncryptorAesGcmPassword aes = new EncryptorAesGcmPassword(secret_key);
		SimplifiedAes aes = new SimplifiedAes(secret_key);
		//System.out.println("pText: " + pText);
		String encryptedTextBase64 = aes.encrypt(pText.getBytes(StandardCharsets.UTF_8));
		// String decryptedText = aes.decrypt(encryptedTextBase64);
		RegisterDao dao = new RegisterDao(db_url, db_username, db_password);
		if (!dao.hasRegistered(username, email)) {
			if (cookies_enabled.equals("yes")) {
				if (email_notification_enabled.equals("yes"))
					JavaMailUtil.sendMail(email);
				Cookie username_cookie = new Cookie("username_cookie", username);
				username_cookie.setPath("/");
				response.addCookie(username_cookie);
			}
			dao.insertUser(username, email, encryptedTextBase64);
			response.sendRedirect("showRegister");
		} else
			response.sendRedirect("failRegister");
	}

	@RequestMapping(value = "/showRegister", method = RequestMethod.GET)
	public ModelAndView showRegister() {
		ModelAndView model = new ModelAndView("showRegister");
		return model;
	}

	@RequestMapping(value = "/failRegister", method = RequestMethod.GET)
	public ModelAndView failRegister() {
		ModelAndView model = new ModelAndView("failRegister");
		return model;
	}

	@RequestMapping(value = "/goToLogin", method = RequestMethod.GET)
	public ModelAndView goToLogin() {
		ModelAndView model = new ModelAndView("login");
		return model;
	}

	@RequestMapping(value = { "/getLogin" }, method = RequestMethod.GET)
	public void getLogin(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String username = request.getParameter("username");
		String pText = request.getParameter("password");
		SimplifiedAes aes = new SimplifiedAes(secret_key);
		String encryptedTextBase64 = aes.encrypt(pText.getBytes(StandardCharsets.UTF_8));
		LoginDao dao = new LoginDao(db_url, db_username, db_password);
		HttpSession session = request.getSession();
		session.setAttribute("username", username);

		if (dao.matchUser(username, encryptedTextBase64)) {
			if (cookies_enabled.equals("yes")) {
				Cookie username_cookie = new Cookie("username_cookie", username);
				username_cookie.setPath("/");
				response.addCookie(username_cookie);
				//System.out.println("Write username cookie: " + username_cookie);
			}
			response.sendRedirect("home");
		} else
			response.sendRedirect("failLogin");
	}

	@RequestMapping(value = "/failLogin", method = RequestMethod.GET)
	public ModelAndView failLogin() {
		ModelAndView model = new ModelAndView("failLogin");
		return model;
	}

	@RequestMapping(value = "/goToForgot", method = RequestMethod.GET)
	public ModelAndView goToForgot() {
		ModelAndView model = new ModelAndView("forgot");
		return model;
	}

	@RequestMapping(value = { "/getRetrieve" }, method = RequestMethod.GET)
	public void getRetrieve(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SimplifiedAes aes = new SimplifiedAes(secret_key);
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		RetrieveDao dao = new RetrieveDao(db_url, db_username, db_password);
		String passwordStr = dao.findPassword(username, email);
		String decryptedText = aes.decrypt(passwordStr);
		HttpSession session = request.getSession();
		session.setAttribute("password", decryptedText);
		if (passwordStr.equals("ERROR"))
			response.sendRedirect("goToForgot");
		else
			response.sendRedirect("goToRetrieve");
	}

	@RequestMapping(value = "/goToRetrieve", method = RequestMethod.GET)
	public ModelAndView goToRetrieve() {
		ModelAndView model = new ModelAndView("retrieve");
		return model;
	}

	@RequestMapping(value = { "/getLogout" }, method = RequestMethod.GET)
	public void getLogout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.setAttribute("username", null);
		Cookie[] cookies = request.getCookies();
	    if (clearCookiesOnLogout.equals("yes")) {
			if (cookies != null)
		        for (Cookie cookie : cookies) {
		            cookie.setValue("");
		            cookie.setPath("/");
		            cookie.setMaxAge(0);
		            response.addCookie(cookie);
		        }
	    }
		response.sendRedirect("goToLogout");
	}

	@RequestMapping(value = "/goToLogout", method = RequestMethod.GET)
	public ModelAndView goToLogout() {
		ModelAndView model = new ModelAndView("home");
		return model;
	}

	@RequestMapping(value = { "/goToTest" }, method = RequestMethod.GET)
	public void doTest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String username = "JJT5";
		String pText = "123456";
		SimplifiedAes aes = new SimplifiedAes(secret_key);
		System.out.println("pText: " + pText);
		String encryptedTextBase64 = aes.encrypt(pText.getBytes(StandardCharsets.UTF_8));
		System.out.println("Encrypted: " + encryptedTextBase64);
		String decryptedText = aes.decrypt(encryptedTextBase64);
		System.out.println("Decrypted: " + decryptedText);

		// String encryptedTextBase64 =
		// aes.encrypt(pText.getBytes(StandardCharsets.UTF_8));
		LoginDao dao = new LoginDao(db_url, db_username, db_password);
		HttpSession session = request.getSession();
		session.setAttribute("username", username);
		// System.out.println("Password: " + pText);
		// System.out.println("EncryptedTextBase64: " + encryptedTextBase64);
		// String decryptedText = aes.decrypt(encryptedTextBase64);
		// System.out.println("Decrypted: " + decryptedText);
		// dao.matchUser(username, encryptedTextBase64);
		if (dao.matchUser(username, encryptedTextBase64)) {
			response.sendRedirect("home");
		} else
			response.sendRedirect("failLogin");
	}
	@RequestMapping(value = { "/goToTestEmail" }, method = RequestMethod.GET)
	public void doTestEmail(HttpServletRequest request, HttpServletResponse response) throws Exception {
		JavaMailUtil.sendMail("jjtioe123@gmail.com");
	}
	
	@RequestMapping(value = { "/goToRunning" }, method = RequestMethod.GET)
	protected ModelAndView doShowRunning() {
		ModelAndView model = new ModelAndView("peachtreeWave");
		return model;
	}
}