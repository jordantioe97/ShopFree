package com.orbit.dao;

import java.sql.*;
import java.util.ArrayList;

public class ItemCategoryDao 
{
	private String db_url;
	private String db_username;
	private String db_password;
	public ItemCategoryDao(String url, String username, String password) {
		db_url = url;
		db_username = username;
		db_password = password;
	}
	public ArrayList<ItemCategory> getItemCategory(int cat_id)
	{
		ArrayList<ItemCategory> itemCategoryList = new ArrayList<ItemCategory>();
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(db_url,db_username,db_password);
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT category.category_name,item_name,picture,description,link\r\n"
					+ "FROM item,category\r\n"
					+ "WHERE item.category_id=category.id\r\n"
					+ "AND item.category_id = " + cat_id);
			while (rs.next()) {
				ItemCategory ic = new ItemCategory();
				ic.setCategory_name(rs.getString("category_name"));
				ic.setItem_name(rs.getString("item_name"));
				ic.setPicture(rs.getString("picture"));
				ic.setDescription(rs.getString("description"));
				ic.setLink(rs.getString("link"));
				
				itemCategoryList.add(ic);
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return itemCategoryList;
	}
	
}