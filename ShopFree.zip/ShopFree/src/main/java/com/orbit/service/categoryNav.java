package com.orbit.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.orbit.dao.Category;

public class categoryNav {
	
	public ArrayList<Category> getCategory() {
		ArrayList<Category> categoryList = new ArrayList<Category>();
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			//File configFile = new File("C:\\Users\\jorda\\eclipse-workspace\\ShopFree\\src\\main\\webapp\\WEB-INF\\pages\\category.xml");
			//Document doc = db.parse(configFile);
			//InputStream input = categoryNav.class.getClassLoader().getResourceAsStream("../webapp/resources/configuration/navbar_category.xml");
			InputStream input = categoryNav.class.getClassLoader().getResourceAsStream("navbar_category.xml");
			Document doc = db.parse(input);
			doc.getDocumentElement().normalize();
			
			NodeList nodeList = doc.getElementsByTagName("category");
			
			for (int itr = 0; itr < nodeList.getLength(); itr++)   
			{
				Node node = nodeList.item(itr);  
				System.out.println();  
				if (node.getNodeType() == Node.ELEMENT_NODE)   
				{  
					Element eElement = (Element) node;  				
					Category cat = new Category();
					cat.setCategory_id(eElement.getElementsByTagName("id").item(0).getTextContent());
					cat.setCategory_name(eElement.getElementsByTagName("name").item(0).getTextContent());
					categoryList.add(cat);
				}
			}
			return categoryList;
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}
		return categoryList;
	}
}
