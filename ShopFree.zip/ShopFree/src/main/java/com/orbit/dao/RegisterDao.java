package com.orbit.dao;

import java.sql.*;
public class RegisterDao {
	private String db_url;
	private String db_username;
	private String db_password;
	public RegisterDao(String url, String username, String password) {
		db_url = url;
		db_username = username;
		db_password = password;
	}
	public boolean hasRegistered(String username, String email) {	
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(db_url,db_username,db_password);
			Statement st = con.createStatement();
			String sqlString = "select username, email from user where username = " + "\"" + username + "\"" + " or email = " + "\"" + email + "\"";
			ResultSet rs = st.executeQuery(sqlString);
			if (rs.next()) {
				System.out.println("Username or email already exists.");
				return true;
			}
			else {
				return false;
			}	
			
		}
		catch(Exception e){
			System.out.println(e);
		}
		return false;
	}
	public void insertUser(String username, String email, String password) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/go_shopping","root","admin");
			Statement st = con.createStatement();
			String sqlString = "insert into user(username, email, password) values " + "('" + username + "', " + "'" + email + "', " + "'" + password + "')";
			int i = st.executeUpdate(sqlString);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
